"""
Carbon Emissions Impact Analysis
================================
A comprehensive analysis examining the relationship between global CO2 concentrations 
and temperature anomalies from 1961-2023.

Author: Rashad
Repository: https://github.com/Rashad1019/carbon_emissions
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.stats import pearsonr, spearmanr
from sklearn.linear_model import LinearRegression
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# Set style for all plots
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("husl")

# =============================================================================
# DATA LOADING AND PREPROCESSING
# =============================================================================

print("=" * 60)
print("CARBON EMISSIONS IMPACT ANALYSIS")
print("=" * 60)

# Load CO2 data
co2_df = pd.read_csv('/mnt/user-data/uploads/carbon_emmission.csv')
print(f"\nCO2 Data Shape: {co2_df.shape}")
print(f"CO2 Data Columns: {co2_df.columns.tolist()}")

# Load temperature data
temp_df = pd.read_csv('/mnt/user-data/uploads/temperature.csv')
print(f"\nTemperature Data Shape: {temp_df.shape}")
print(f"Temperature Data Columns (first 10): {temp_df.columns.tolist()[:10]}...")

# =============================================================================
# CO2 DATA PROCESSING
# =============================================================================

# Parse the Date column and filter for actual CO2 values (not small decimals which appear to be something else)
co2_df['Year'] = co2_df['Date'].str[:4].astype(int)
co2_df['Month'] = co2_df['Date'].str[5:7].astype(int)

# Filter for actual CO2 ppm values (typically > 300)
co2_ppm = co2_df[co2_df['Value'] > 100].copy()
print(f"\nFiltered CO2 records: {len(co2_ppm)}")

# Calculate yearly averages
co2_yearly = co2_ppm.groupby('Year')['Value'].mean().reset_index()
co2_yearly.columns = ['Year', 'CO2_ppm']
print(f"CO2 yearly data range: {co2_yearly['Year'].min()} - {co2_yearly['Year'].max()}")

# =============================================================================
# TEMPERATURE DATA PROCESSING
# =============================================================================

# Melt the temperature data from wide to long format
year_cols = [col for col in temp_df.columns if col.startswith('F')]
temp_long = temp_df.melt(
    id_vars=['ObjectId', 'Country', 'ISO2', 'ISO3'],
    value_vars=year_cols,
    var_name='Year_col',
    value_name='TempAnomaly'
)

# Extract year from column names (F1961 -> 1961)
temp_long['Year'] = temp_long['Year_col'].str[1:].astype(int)

# Calculate global average temperature anomaly per year
temp_yearly = temp_long.groupby('Year')['TempAnomaly'].mean().reset_index()
temp_yearly.columns = ['Year', 'TempChange']
print(f"Temperature yearly data range: {temp_yearly['Year'].min()} - {temp_yearly['Year'].max()}")

# =============================================================================
# MERGE DATASETS
# =============================================================================

merged = pd.merge(co2_yearly, temp_yearly, on='Year', how='inner')
print(f"\nMerged dataset shape: {merged.shape}")
print(f"Analysis period: {merged['Year'].min()} - {merged['Year'].max()}")
print(f"\nMerged Data Summary:")
print(merged.describe())

# =============================================================================
# STATISTICAL ANALYSIS
# =============================================================================

print("\n" + "=" * 60)
print("STATISTICAL ANALYSIS")
print("=" * 60)

# Correlation Analysis
pearson_corr, pearson_p = pearsonr(merged['CO2_ppm'], merged['TempChange'])
spearman_corr, spearman_p = spearmanr(merged['CO2_ppm'], merged['TempChange'])

print(f"\nCorrelation Analysis:")
print(f"  Pearson Correlation:  {pearson_corr:.4f} (p-value: {pearson_p:.2e})")
print(f"  Spearman Correlation: {spearman_corr:.4f} (p-value: {spearman_p:.2e})")

# Linear Regression
X = merged['CO2_ppm'].values.reshape(-1, 1)
y = merged['TempChange'].values
model = LinearRegression()
model.fit(X, y)
r_squared = model.score(X, y)

print(f"\nLinear Regression:")
print(f"  R-squared: {r_squared:.4f}")
print(f"  Slope: {model.coef_[0]:.6f} °C per ppm CO2")
print(f"  Intercept: {model.intercept_:.4f}")

# Rate of change analysis
co2_change = merged['CO2_ppm'].iloc[-1] - merged['CO2_ppm'].iloc[0]
temp_change = merged['TempChange'].iloc[-1] - merged['TempChange'].iloc[0]
years_span = merged['Year'].iloc[-1] - merged['Year'].iloc[0]

print(f"\nTrend Analysis ({merged['Year'].iloc[0]}-{merged['Year'].iloc[-1]}):")
print(f"  CO2 increase: {co2_change:.2f} ppm ({co2_change/years_span:.2f} ppm/year)")
print(f"  Temperature increase: {temp_change:.2f}°C ({temp_change/years_span:.4f}°C/year)")

# =============================================================================
# CREATE VISUALIZATIONS
# =============================================================================

print("\n" + "=" * 60)
print("GENERATING VISUALIZATIONS")
print("=" * 60)

# Create output directory
import os
os.makedirs('/home/claude/figures', exist_ok=True)

# Figure 1: Time Series - Dual Axis Plot
fig1, ax1 = plt.subplots(figsize=(12, 6))

color1 = '#2E86AB'
color2 = '#E94F37'

ax1.set_xlabel('Year', fontsize=12)
ax1.set_ylabel('CO₂ Concentration (ppm)', color=color1, fontsize=12)
line1 = ax1.plot(merged['Year'], merged['CO2_ppm'], color=color1, linewidth=2.5, 
                  marker='o', markersize=4, label='CO₂ Concentration')
ax1.tick_params(axis='y', labelcolor=color1)
ax1.set_ylim([merged['CO2_ppm'].min() - 10, merged['CO2_ppm'].max() + 10])

ax2 = ax1.twinx()
ax2.set_ylabel('Temperature Anomaly (°C)', color=color2, fontsize=12)
line2 = ax2.plot(merged['Year'], merged['TempChange'], color=color2, linewidth=2.5,
                  marker='s', markersize=4, label='Temperature Anomaly')
ax2.tick_params(axis='y', labelcolor=color2)

# Combined legend
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=10)

plt.title('CO₂ Concentrations and Global Temperature Anomalies Over Time\n(1961-2022)', 
          fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/claude/figures/01_time_series.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Time series plot saved")

# Figure 2: Correlation Scatter Plot with Regression Line
fig2, ax = plt.subplots(figsize=(10, 8))

scatter = ax.scatter(merged['CO2_ppm'], merged['TempChange'], 
                     c=merged['Year'], cmap='viridis', s=80, alpha=0.8, edgecolors='white')

# Add regression line
x_line = np.linspace(merged['CO2_ppm'].min(), merged['CO2_ppm'].max(), 100)
y_line = model.predict(x_line.reshape(-1, 1))
ax.plot(x_line, y_line, 'r--', linewidth=2, label=f'Linear Fit (R² = {r_squared:.3f})')

# Add colorbar for years
cbar = plt.colorbar(scatter)
cbar.set_label('Year', fontsize=11)

ax.set_xlabel('CO₂ Concentration (ppm)', fontsize=12)
ax.set_ylabel('Global Temperature Anomaly (°C)', fontsize=12)
ax.set_title(f'Correlation: CO₂ vs Temperature Anomaly\nPearson r = {pearson_corr:.3f}', 
             fontsize=14, fontweight='bold')
ax.legend(loc='upper left', fontsize=10)

# Add annotation box
textstr = f'Correlation: {pearson_corr:.3f}\nR² = {r_squared:.3f}\nSlope: {model.coef_[0]:.4f} °C/ppm'
props = dict(boxstyle='round', facecolor='wheat', alpha=0.8)
ax.text(0.95, 0.05, textstr, transform=ax.transAxes, fontsize=10,
        verticalalignment='bottom', horizontalalignment='right', bbox=props)

plt.tight_layout()
plt.savefig('/home/claude/figures/02_correlation_scatter.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Correlation scatter plot saved")

# Figure 3: Correlation Heatmap
fig3, ax = plt.subplots(figsize=(8, 6))

corr_matrix = merged[['CO2_ppm', 'TempChange']].corr()
corr_matrix.index = ['CO₂ Concentration', 'Temperature Change']
corr_matrix.columns = ['CO₂ Concentration', 'Temperature Change']

sns.heatmap(corr_matrix, annot=True, cmap='RdBu_r', center=0, 
            square=True, linewidths=2, annot_kws={'size': 14, 'weight': 'bold'},
            fmt='.3f', vmin=-1, vmax=1)
plt.title('Correlation Heatmap', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/claude/figures/03_correlation_heatmap.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Correlation heatmap saved")

# Figure 4: Decade Analysis
merged['Decade'] = (merged['Year'] // 10) * 10
decade_stats = merged.groupby('Decade').agg({
    'CO2_ppm': 'mean',
    'TempChange': 'mean',
    'Year': 'count'
}).rename(columns={'Year': 'Years_Count'})

fig4, axes = plt.subplots(1, 2, figsize=(14, 5))

# CO2 by decade
bars1 = axes[0].bar(decade_stats.index.astype(str) + 's', decade_stats['CO2_ppm'], 
                    color='#2E86AB', edgecolor='black', linewidth=1.2)
axes[0].set_xlabel('Decade', fontsize=12)
axes[0].set_ylabel('Average CO₂ (ppm)', fontsize=12)
axes[0].set_title('Average CO₂ Concentration by Decade', fontsize=13, fontweight='bold')
for bar, val in zip(bars1, decade_stats['CO2_ppm']):
    axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2, 
                 f'{val:.1f}', ha='center', va='bottom', fontsize=9)

# Temperature by decade
bars2 = axes[1].bar(decade_stats.index.astype(str) + 's', decade_stats['TempChange'], 
                    color='#E94F37', edgecolor='black', linewidth=1.2)
axes[1].set_xlabel('Decade', fontsize=12)
axes[1].set_ylabel('Average Temperature Anomaly (°C)', fontsize=12)
axes[1].set_title('Average Temperature Anomaly by Decade', fontsize=13, fontweight='bold')
for bar, val in zip(bars2, decade_stats['TempChange']):
    axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, 
                 f'{val:.2f}', ha='center', va='bottom', fontsize=9)

plt.tight_layout()
plt.savefig('/home/claude/figures/04_decade_analysis.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Decade analysis plot saved")

# Figure 5: Rate of Change Analysis
merged['CO2_change'] = merged['CO2_ppm'].diff()
merged['Temp_change'] = merged['TempChange'].diff()

fig5, axes = plt.subplots(2, 1, figsize=(12, 8), sharex=True)

axes[0].bar(merged['Year'][1:], merged['CO2_change'][1:], color='#2E86AB', alpha=0.7)
axes[0].axhline(y=merged['CO2_change'].mean(), color='red', linestyle='--', 
                linewidth=2, label=f'Mean: {merged["CO2_change"].mean():.2f} ppm/year')
axes[0].set_ylabel('Year-over-Year CO₂ Change (ppm)', fontsize=11)
axes[0].set_title('Annual Rate of Change in CO₂ Concentration', fontsize=13, fontweight='bold')
axes[0].legend()

axes[1].bar(merged['Year'][1:], merged['Temp_change'][1:], color='#E94F37', alpha=0.7)
axes[1].axhline(y=merged['Temp_change'].mean(), color='blue', linestyle='--', 
                linewidth=2, label=f'Mean: {merged["Temp_change"].mean():.3f} °C/year')
axes[1].set_xlabel('Year', fontsize=12)
axes[1].set_ylabel('Year-over-Year Temp Change (°C)', fontsize=11)
axes[1].set_title('Annual Rate of Change in Temperature Anomaly', fontsize=13, fontweight='bold')
axes[1].legend()

plt.tight_layout()
plt.savefig('/home/claude/figures/05_rate_of_change.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Rate of change plot saved")

# Figure 6: K-Means Clustering
scaler = StandardScaler()
clustering_data = merged[['CO2_ppm', 'TempChange']].dropna()
scaled_data = scaler.fit_transform(clustering_data)

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
clusters = kmeans.fit_predict(scaled_data)

fig6, ax = plt.subplots(figsize=(10, 8))

colors = ['#2E86AB', '#E94F37', '#F6AE2D']
cluster_names = ['Low CO₂ & Temp', 'Moderate CO₂ & Temp', 'High CO₂ & Temp']

# Sort clusters by CO2 level for consistent naming
cluster_means = pd.DataFrame({
    'Cluster': range(3),
    'CO2_mean': [clustering_data.iloc[clusters == i]['CO2_ppm'].mean() for i in range(3)]
}).sort_values('CO2_mean')

cluster_mapping = {old: new for new, old in enumerate(cluster_means['Cluster'])}
clusters_sorted = np.array([cluster_mapping[c] for c in clusters])

for i, (name, color) in enumerate(zip(cluster_names, colors)):
    mask = clusters_sorted == i
    ax.scatter(clustering_data.iloc[mask]['CO2_ppm'], 
               clustering_data.iloc[mask]['TempChange'],
               c=color, label=name, s=100, alpha=0.7, edgecolors='white')

ax.set_xlabel('CO₂ Concentration (ppm)', fontsize=12)
ax.set_ylabel('Temperature Anomaly (°C)', fontsize=12)
ax.set_title('Climate Pattern Clustering (K-Means, k=3)', fontsize=14, fontweight='bold')
ax.legend(title='Climate Pattern', fontsize=10)

plt.tight_layout()
plt.savefig('/home/claude/figures/06_clustering.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Clustering plot saved")

# Figure 7: What-If Scenario Analysis
current_co2 = merged['CO2_ppm'].iloc[-1]
scenarios = {
    'Current': 0,
    '+10% CO₂': 10,
    '+20% CO₂': 20,
    '-10% CO₂': -10,
    '-20% CO₂': -20
}

scenario_results = {}
for name, pct_change in scenarios.items():
    new_co2 = current_co2 * (1 + pct_change / 100)
    predicted_temp = model.predict([[new_co2]])[0]
    scenario_results[name] = {'CO2': new_co2, 'Temp': predicted_temp}

fig7, ax = plt.subplots(figsize=(10, 6))

names = list(scenario_results.keys())
temps = [scenario_results[n]['Temp'] for n in names]
colors = ['#2E86AB' if 'Current' in n else '#E94F37' if '+' in n else '#28A745' for n in names]

bars = ax.bar(names, temps, color=colors, edgecolor='black', linewidth=1.2)

for bar, temp, name in zip(bars, temps, names):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
            f'{temp:.2f}°C', ha='center', va='bottom', fontsize=10, fontweight='bold')

ax.set_ylabel('Predicted Temperature Anomaly (°C)', fontsize=12)
ax.set_title('What-If Scenario Analysis: Impact of CO₂ Changes on Temperature', 
             fontsize=14, fontweight='bold')
ax.axhline(y=temps[0], color='gray', linestyle='--', alpha=0.5)

plt.tight_layout()
plt.savefig('/home/claude/figures/07_scenario_analysis.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Scenario analysis plot saved")

# Figure 8: Combined Dashboard Summary
fig8, axes = plt.subplots(2, 2, figsize=(14, 10))

# Time series (simplified)
axes[0, 0].plot(merged['Year'], merged['CO2_ppm'], 'b-', linewidth=2, label='CO₂ (ppm)')
ax_twin = axes[0, 0].twinx()
ax_twin.plot(merged['Year'], merged['TempChange'], 'r-', linewidth=2, label='Temp (°C)')
axes[0, 0].set_xlabel('Year')
axes[0, 0].set_ylabel('CO₂ (ppm)', color='blue')
ax_twin.set_ylabel('Temp Anomaly (°C)', color='red')
axes[0, 0].set_title('Time Series Overview', fontweight='bold')

# Correlation
axes[0, 1].scatter(merged['CO2_ppm'], merged['TempChange'], c=merged['Year'], cmap='viridis', s=50)
axes[0, 1].plot(x_line, y_line, 'r--', linewidth=2)
axes[0, 1].set_xlabel('CO₂ (ppm)')
axes[0, 1].set_ylabel('Temp Anomaly (°C)')
axes[0, 1].set_title(f'Correlation (r = {pearson_corr:.3f})', fontweight='bold')

# Decade comparison
x_pos = np.arange(len(decade_stats))
width = 0.35
axes[1, 0].bar(x_pos - width/2, decade_stats['CO2_ppm']/10, width, label='CO₂/10', color='#2E86AB')
axes[1, 0].bar(x_pos + width/2, decade_stats['TempChange']*10, width, label='Temp×10', color='#E94F37')
axes[1, 0].set_xticks(x_pos)
axes[1, 0].set_xticklabels([f"{d}s" for d in decade_stats.index])
axes[1, 0].set_xlabel('Decade')
axes[1, 0].legend()
axes[1, 0].set_title('Scaled Decade Comparison', fontweight='bold')

# Key metrics
axes[1, 1].axis('off')
metrics_text = f"""
KEY FINDINGS
═══════════════════════════════════

📊 Correlation: {pearson_corr:.3f}

📈 CO₂ Increase: {co2_change:.1f} ppm
   ({merged['Year'].iloc[0]} → {merged['Year'].iloc[-1]})

🌡️ Temperature Rise: {temp_change:.2f}°C
   ({merged['Year'].iloc[0]} → {merged['Year'].iloc[-1]})

📉 CO₂ Growth Rate: {co2_change/years_span:.2f} ppm/year

🔥 Warming Rate: {temp_change/years_span:.4f} °C/year

📐 Model R²: {r_squared:.3f}
"""
axes[1, 1].text(0.1, 0.5, metrics_text, transform=axes[1, 1].transAxes,
                fontsize=12, verticalalignment='center', fontfamily='monospace',
                bbox=dict(boxstyle='round', facecolor='lightgray', alpha=0.8))

plt.suptitle('Carbon Emissions Impact Analysis - Summary Dashboard', 
             fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/claude/figures/08_dashboard_summary.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Dashboard summary saved")

# =============================================================================
# SAVE PROCESSED DATA
# =============================================================================

merged.to_csv('/home/claude/processed_data.csv', index=False)
print("\n  ✓ Processed data saved to processed_data.csv")

# =============================================================================
# GENERATE ANALYSIS SUMMARY
# =============================================================================

print("\n" + "=" * 60)
print("ANALYSIS COMPLETE")
print("=" * 60)

summary = f"""
CARBON EMISSIONS IMPACT ANALYSIS - SUMMARY
==========================================

DATA OVERVIEW:
- Analysis Period: {merged['Year'].min()} - {merged['Year'].max()} ({years_span} years)
- CO₂ Data Points: {len(co2_ppm)} monthly observations
- Temperature Data: {len(temp_df)} countries/regions

KEY STATISTICS:
- Starting CO₂ Level: {merged['CO2_ppm'].iloc[0]:.2f} ppm
- Ending CO₂ Level: {merged['CO2_ppm'].iloc[-1]:.2f} ppm
- CO₂ Increase: {co2_change:.2f} ppm ({(co2_change/merged['CO2_ppm'].iloc[0])*100:.1f}%)

- Starting Temp Anomaly: {merged['TempChange'].iloc[0]:.3f}°C
- Ending Temp Anomaly: {merged['TempChange'].iloc[-1]:.3f}°C
- Temperature Rise: {temp_change:.3f}°C

CORRELATION ANALYSIS:
- Pearson Correlation: {pearson_corr:.4f} (p < 0.001)
- Spearman Correlation: {spearman_corr:.4f} (p < 0.001)
- R-squared: {r_squared:.4f}

REGRESSION MODEL:
- Slope: {model.coef_[0]:.6f} °C per ppm CO₂
- Interpretation: Each 1 ppm increase in CO₂ is associated with 
  a {model.coef_[0]:.4f}°C increase in temperature anomaly

WHAT-IF SCENARIOS (based on current CO₂ = {current_co2:.2f} ppm):
- 10% CO₂ reduction → Predicted temp: {scenario_results['-10% CO₂']['Temp']:.2f}°C
- 20% CO₂ reduction → Predicted temp: {scenario_results['-20% CO₂']['Temp']:.2f}°C
- 10% CO₂ increase → Predicted temp: {scenario_results['+10% CO₂']['Temp']:.2f}°C
- 20% CO₂ increase → Predicted temp: {scenario_results['+20% CO₂']['Temp']:.2f}°C

VISUALIZATIONS GENERATED:
1. Time Series Plot (CO₂ and Temperature over time)
2. Correlation Scatter Plot with Regression Line
3. Correlation Heatmap
4. Decade Analysis (Bar Charts)
5. Rate of Change Analysis
6. K-Means Clustering of Climate Patterns
7. What-If Scenario Analysis
8. Summary Dashboard
"""

print(summary)

# Save summary to file
with open('/home/claude/analysis_summary.txt', 'w') as f:
    f.write(summary)
print("\n  ✓ Analysis summary saved to analysis_summary.txt")
